import HeaderText from "../../component/HeaderText";
import { tokens } from "../../theme";
import { useTheme, Box } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useSelector, useDispatch } from "react-redux";

const Product = () => {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode)
  const productData = useSelector((d) => d.productData);
  const categoryData = useSelector(d=> d.categoryData);
  // console.log(productData);
  const columns = [
    {
      field: "id",
      headerName: "ID",
    },
    {
      field: "name",
      headerName: "Name",
      flex: 0.5
    },
    {
      field: "image",
      headerName: "Image",
      renderCell: (params)=>(
        <Box
          width="40px"
          height="40px"
          sx={{
            borderRadius: "50%",
            backgroundImage: `url(${params.value})`,
            backgroundSize: "cover"
          }}
        ></Box>
      )
    },
    {
      field: "description",
      headerName: "Description",
      flex: 1
    },
    {
      field: "categoryId",
      headerName: "Category",
      renderCell: (params)=>(
        categoryData.find(a=> a.id=== params.value).name
      )
    }
  ];

  return (
    <Box
      m="50px 30px"
      height="69vh"
      sx={{
        " .header-center .MuiDataGrid-columnHeaderTitleContainer": {
          justifyContent: "center",
        },
        ".MuiButton-text": {
          color: theme.palette.mode === "dark" ? "white" : "black",
        },
      }}
    >
      <HeaderText title="Product" description="View, Edit or Delete product" />
      <DataGrid columns={columns} rows={productData}/>
    </Box>
  );
};

export default Product;
