import HeaderText from "../../component/HeaderText";
import { Box } from "@mui/material";
import ProductForm from "../../component/ProductForm";
import { useState } from "react";
import postAPI from "../../api/postAPI";

const AddProduct = () =>{
    const [display, setDisplay] = useState("none");

    const handleFormSubmit = (values)=>{
        alert(JSON.stringify(values, null, 2));
        postAPI(`category/${values.categoryId}/product`, values)
        .then(response=>{
            console.log(response);
        })
        .catch(error=>{
            console.error(error)
        })
    }



    return (
        <Box sx={{margin: "50px 30px"}}>
            <HeaderText title="Add Product" description="Create or add product here" />
            <ProductForm handleFormSubmit={handleFormSubmit} display={display}/>
        </Box>
    )
}

export default AddProduct;