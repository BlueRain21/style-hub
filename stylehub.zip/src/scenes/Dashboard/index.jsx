import { useSelector } from "react-redux";
import { useEffect } from "react";

const Dashboard = () =>{
    const userData = useSelector(data=> data.userData);








    return (
        <>
            Dashboard
        </>
    )
}


export default Dashboard;