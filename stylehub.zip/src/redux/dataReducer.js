import getAPI from "../api/getAPI";

export const initialState = {
    userData :[],
    categoryData: [],
    productData: [],
}


const dataReducer = (state=initialState, action)=>{
    switch(action.type){
        case "UPDATE USER DATA":
            return {...state, userData:action.payload};
        case "UPDATE CATEGORY DATA":
            return {...state, categoryData: action.payload};
        case "EMPTY PRODUCT DATA":
                return {...state, productData: []};
        case "UPDATE PRODUCT DATA":
            const pid = state.productData.map(d=> d.id);
            return {...state, productData: [...state.productData, ...action.payload.filter(d=> pid.indexOf(d.id)=== -1)]};
        default:
            return state;
    }
}

export default dataReducer;